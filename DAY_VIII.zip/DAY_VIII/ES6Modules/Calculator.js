import * as MathModule from "./Math.js";
console.log("Product is :" + MathModule.Product(30, 20));

// import Addition, { Product } from "./Math.js";
// console.log("Addition is :" + Addition(30, 20));
// console.log("Products is :" + Product(30, 20));

// import { Add } from "./Math.js";
// console.log("Addition is :" + Add(10, 20));
