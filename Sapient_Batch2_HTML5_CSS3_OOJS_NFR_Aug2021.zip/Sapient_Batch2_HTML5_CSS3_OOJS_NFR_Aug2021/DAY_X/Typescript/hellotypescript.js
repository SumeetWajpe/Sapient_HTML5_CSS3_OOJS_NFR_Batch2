// let x = 10; // implicit typed number
// x = "Hello";
let x; // annotation
// optional parameters
// function Add(x?:number,y?:number){
//     return x + y
// }
// Add();
// Add("sadsd","asds")
// Default
function Add(x = 0, y = 0) {
    if (x < 0)
        return "Error !";
    return x + y;
}
let result = Add(20, 30);
console.log(result);
var i; // type-> any
i = 10;
i = "Hello";
i = { o: 1 };
var cars = ["BMW", "Audi"];
var moreCars = new Array();
moreCars[0] = "TATA";
class Emp {
}
class Manager extends Emp {
    constructor() {
        super();
        // this.salary
    }
}
var emp = new Emp();
// emp.name
