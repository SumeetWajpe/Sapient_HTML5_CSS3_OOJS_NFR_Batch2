// let x = 10; // implicit typed number
// x = "Hello";

let x: number; // annotation

// optional parameters
// function Add(x?:number,y?:number){
//     return x + y
// }

// Add();

// Add("sadsd","asds")

// Default
function Add(x: number = 0, y: number = 0): number | string {
  if (x < 0) return "Error !";
  return x + y;
}
let result: number | string = Add(20, 30);
console.log(result);

var i; // type-> any
i = 10;
i = "Hello";
i = { o: 1 };

var cars: string[] = ["BMW", "Audi"];

var moreCars = new Array<string>();
moreCars[0] = "TATA";

class Emp {
  private id;
  public name;
  protected salary;
}

class Manager extends Emp {
  constructor() {
    super();
    // this.salary
  }
}

var emp = new Emp();
// emp.name
